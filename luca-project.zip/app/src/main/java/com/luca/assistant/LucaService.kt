package com.luca.assistant

import android.Manifest
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class LucaService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speaking = false
    private var running = true
    private var chatMode = false
    private var wl: PowerManager.WakeLock? = null
    private var awakeUntil = 0L
    private val history = mutableListOf<Pair<String, String>>()
    private val speakGuard = Runnable { if (speaking) { speaking = false; listen() } }
    private val wake = Regex("""(?:\b(?:luca|luka|lucca|lukka|loka|looka)\b|লুকা|লুকো|লুকাস)""", RegexOption.IGNORE_CASE)
    private fun bn() = getSharedPreferences("luca", MODE_PRIVATE).getString("lang", "en") == "bn"
    private val bnApps = mapOf(
        "হোয়াটসঅ্যাপ" to "whatsapp", "ইউটিউব" to "youtube", "ফেসবুক" to "facebook",
        "মেসেঞ্জার" to "messenger", "জিমেইল" to "gmail", "ক্রোম" to "chrome", "ম্যাপ" to "maps", "গুগল ম্যাপ" to "maps",
        "ইনস্টাগ্রাম" to "instagram", "টেলিগ্রাম" to "telegram", "টিকটক" to "tiktok", "স্পটিফাই" to "spotify",
        "নেটফ্লিক্স" to "netflix", "জুম" to "zoom", "ক্যামেরা" to "camera", "সেটিংস" to "settings", "সেটিং" to "settings",
        "ওয়াইফাই" to "wifi", "ওয়াই-ফাই" to "wifi", "ব্লুটুথ" to "bluetooth", "ফোন" to "phone", "ডায়ালার" to "dialer",
        "গ্যালারি" to "photos", "ক্যালকুলেটর" to "calculator", "ঘড়ি" to "clock", "বিকাশ" to "bkash", "নগদ" to "nagad",
        "ক্লড" to "claude", "চ্যাটজিপিটি" to "chatgpt", "জেমিনি" to "gemini"
    )

    private fun fixDigits(s: String): String {
        val d = "০১২৩৪৫৬৭৮৯"
        val sb = StringBuilder()
        for (c in s) { val i = d.indexOf(c); sb.append(if (i >= 0) '0' + i else c) }
        return sb.toString()
    }
    private fun bnMs(u: String): Long = when {
        u.contains("সেকেন্ড") -> 1000L
        u.contains("মিনিট") -> 60000L
        else -> 3600000L
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        val n = notif("Luca is listening. Say Hey Luca.", true)
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "luca:listen")
            wl?.acquire()
        } catch (e: Exception) {}
        tts = TextToSpeech(this) { st ->
            ttsReady = st == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.setSpeechRate(1.1f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { h.post { h.removeCallbacks(speakGuard); speaking = false; listen() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { h.post { h.removeCallbacks(speakGuard); speaking = false; listen() } }
                })
                say("Luca is ready.", "লুকা প্রস্তুত।")
            }
        }
        listen()
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        try { sr?.destroy() } catch (e: Exception) {}
        tts?.shutdown()
        try { if (wl?.isHeld == true) wl?.release() } catch (e: Exception) {}
        super.onDestroy()
    }

    private fun notif(text: String, ongoing: Boolean): Notification {
        val ch = "luca"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(ch, "Luca", NotificationManager.IMPORTANCE_LOW))
        }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else Notification.Builder(this)
        return b.setContentTitle("Luca").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(ongoing).build()
    }

    private fun say(en: String, bnText: String = en) {
        if (!ttsReady) return
        var text = en
        if (bn()) {
            val r = tts?.setLanguage(Locale("bn", "BD")) ?: TextToSpeech.ERROR
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED || r == TextToSpeech.ERROR) {
                tts?.setLanguage(Locale.ENGLISH)
            } else text = bnText
        } else tts?.setLanguage(Locale.ENGLISH)
        speaking = true
        try { sr?.cancel() } catch (e: Exception) {}
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.currentTimeMillis())
        h.removeCallbacks(speakGuard)
        h.postDelayed(speakGuard, 25000)
    }

    private fun listen() {
        if (!running || speaking) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        try {
            if (sr == null) {
                val r = SpeechRecognizer.createSpeechRecognizer(this)
                r.setRecognitionListener(object : RecognitionListener {
                    override fun onResults(b: Bundle?) {
                        val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        if (t != null && !speaking) heard(t)
                        h.postDelayed({ listen() }, 40)
                    }
                    override fun onError(e: Int) {
                        if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                            try { sr?.destroy() } catch (x: Exception) {}
                            sr = null
                            h.postDelayed({ listen() }, 800)
                        } else {
                            h.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) 40L else 500L)
                        }
                    }
                    override fun onReadyForSpeech(p: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(p: Bundle?) {}
                    override fun onEvent(t: Int, p: Bundle?) {}
                })
                sr = r
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (bn()) "bn-BD" else "en-US")
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            i.putExtra("android.speech.extras.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 900L)
            i.putExtra("android.speech.extras.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 700L)
            sr?.startListening(i)
        } catch (e: Exception) {
            try { sr?.destroy() } catch (x: Exception) {}
            sr = null
            h.postDelayed({ listen() }, 1500)
        }
    }

    private fun heard(raw: String) {
        val now = System.currentTimeMillis()
        val m = wake.findAll(raw).lastOrNull()
        if (m != null) {
            val rest = raw.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?')
            if (rest.isNotEmpty()) command(rest) else { awakeUntil = now + 8000; say("Yes?", "জি?") }
        } else if (chatMode || now < awakeUntil) {
            awakeUntil = 0
            command(raw)
        }
    }

    private fun go(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            say("Sorry, I could not do that. Allow display over other apps for Luca.")
        }
    }

    private fun mult(u: String): Long = when {
        u.startsWith("hour") -> 3600000L
        u.startsWith("min") -> 60000L
        else -> 1000L
    }

    private fun findPkg(name: String): String? {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val norm = { s: String -> s.lowercase(Locale.getDefault()).replace(Regex("[^a-z0-9\\u0980-\\u09FF]"), "") }
        val key = norm(name)
        if (key.isEmpty()) return null
        var best: String? = null
        for (r in packageManager.queryIntentActivities(q, 0)) {
            val label = norm(r.loadLabel(packageManager).toString())
            if (label == key) return r.activityInfo.packageName
            if (best == null && label.length >= 3 && (label.contains(key) || key.contains(label))) best = r.activityInfo.packageName
        }
        return best
    }

    private fun openApp(n0: String) {
        val n1 = n0.removePrefix("the ").removePrefix("my ").removeSuffix(" app").trim()
        val n = bnApps[n1] ?: n1
        val special = mapOf(
            "settings" to Intent(Settings.ACTION_SETTINGS),
            "wifi" to Intent(Settings.ACTION_WIFI_SETTINGS),
            "wi-fi" to Intent(Settings.ACTION_WIFI_SETTINGS),
            "bluetooth" to Intent(Settings.ACTION_BLUETOOTH_SETTINGS),
            "camera" to Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
            "dialer" to Intent(Intent.ACTION_DIAL),
            "phone" to Intent(Intent.ACTION_DIAL)
        )
        val sp = special[n]
        if (sp != null) { say("Opening $n", "$n খুলছি"); go(sp); return }
        val pkg = findPkg(n)
        val li = if (pkg != null) packageManager.getLaunchIntentForPackage(pkg) else null
        if (li == null) { say("I could not find an app called $n", "$n নামে কোনো অ্যাপ পাইনি"); return }
        say("Opening $n", "$n খুলছি")
        go(li)
    }

    private fun closeApp(n0: String) {
        val n1 = n0.removePrefix("the ").removePrefix("my ").removeSuffix(" app").trim()
        val n = bnApps[n1] ?: n1
        val pkg = findPkg(n)
        go(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))
        if (pkg == null) { say("I could not find $n, but I went to the home screen."); return }
        h.postDelayed({
            try { (getSystemService(ACTIVITY_SERVICE) as ActivityManager).killBackgroundProcesses(pkg) } catch (e: Exception) {}
        }, 1500)
        say("Closing $n", "$n বন্ধ করছি")
    }

    private fun lookup(name: String): String? {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val c = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"), null
        ) ?: return null
        c.use { return if (it.moveToFirst()) it.getString(0) else null }
    }

    private fun numberFor(x: String): String? {
        val d = x.filter { it.isDigit() || it == '+' }
        return if (d.length >= 5) d else lookup(x.trim())
    }

    private fun remind(ms: Long, text: String) {
        h.postDelayed({
            val msg = if (text.isBlank()) "Time is up" else "Reminder: $text"
            say(msg, if (text.isBlank()) "সময় শেষ" else "মনে করিয়ে দিচ্ছি: $text")
            getSystemService(NotificationManager::class.java)
                .notify((System.currentTimeMillis() % 100000).toInt() + 10, notif(msg, false))
        }, ms)
    }

    private fun searchIntent(q: String) = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))

    private fun ask(q: String) {
        val key = (getSharedPreferences("luca", MODE_PRIVATE).getString("key", "") ?: "").trim()
        if (key.isEmpty()) {
            say("Searching for $q", "খুঁজছি: $q")
            go(searchIntent(q)); return
        }
        history.add("user" to q)
        while (history.size > 8) history.removeAt(0)
        val lang = if (bn()) "Bangla" else "English"
        val msgs = JSONArray()
        for (p in history) msgs.put(JSONObject().put("role", p.first).put("content", p.second))
        val body = JSONObject()
            .put("model", "claude-haiku-5-5")
            .put("max_tokens", 250)
            .put("system", "You are Luca, a friendly voice assistant on the user's phone. Reply in $lang in 1 to 3 short spoken sentences. No markdown, no lists, no emojis.")
            .put("messages", msgs)
            .toString()
        thread {
            val out: String = try {
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 8000
                c.readTimeout = 20000
                c.setRequestProperty("x-api-key", key)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                c.setRequestProperty("content-type", "application/json")
                c.doOutput = true
                c.outputStream.use { it.write(body.toByteArray()) }
                val code = c.responseCode
                if (code in 200..299) {
                    val txt = c.inputStream.bufferedReader().use { it.readText() }
                    JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text").trim()
                } else "ERR$code"
            } catch (e: Exception) { "ERRNET" }
            h.post {
                if (out.startsWith("ERR")) {
                    if (history.isNotEmpty()) history.removeAt(history.lastIndex)
                    if (out == "ERRNET") say("I can't reach the internet.", "ইন্টারনেট পাচ্ছি না।")
                    else say("The AI key was rejected or has no credit. Error ${out.removePrefix("ERR")}.", "এআই কী কাজ করছে না। এরর ${out.removePrefix("ERR")}।")
                } else {
                    history.add("assistant" to out)
                    say(out)
                }
            }
        }
    }

    private fun command(raw: String) {
        val t = fixDigits(raw.lowercase(Locale.getDefault()).trim().trimEnd('.', '!', '?', '।'))
        if (Regex("""(stop chat|end chat|chat off|চ্যাট বন্ধ|গল্প বন্ধ)""").containsMatchIn(t)) {
            chatMode = false
            say("Chat mode off. Say Hey Luca for commands.", "চ্যাট মোড বন্ধ। কমান্ডের জন্য লুকা বলুন।"); return
        }
        if (Regex("""(chat mode|let's chat|lets chat|let us chat|start chat|talk to me|চ্যাট করি|চ্যাট মোড|গল্প করি|কথা বলি)""").containsMatchIn(t)) {
            chatMode = true
            say("Chat mode on. Just talk to me.", "চ্যাট মোড চালু। শুধু কথা বলুন।"); return
        }
        if (bn() && commandBn(t)) return
        commandEn(t)
    }

    private fun commandBn(t: String): Boolean {
        if (Regex("""^(বিদায়|থামো|বন্ধ হও)""").containsMatchIn(t)) {
            say("Goodbye", "বিদায়"); h.postDelayed({ stopSelf() }, 1800); return true
        }
        if (t.startsWith("হোম") || t.contains("হোম স্ক্রিন")) {
            go(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)); return true
        }
        Regex("""^(?:সার্চ করো|সার্চ|খোঁজো|খুঁজে দেখো)\s+(.+)""").find(t)?.let {
            say("Searching", "খুঁজছি"); go(searchIntent(it.groupValues[1])); return true
        }
        Regex("""(\d+)\s*(সেকেন্ড|মিনিট|ঘণ্টা|ঘন্টা)\s*(?:পরে|পর)?\s*(.*?)\s*(?:মনে করিয়ে দাও|মনে করিয়ে দিও|রিমাইন্ড করো)""").find(t)?.let {
            remind(it.groupValues[1].toLong() * bnMs(it.groupValues[2]), it.groupValues[3])
            say("Okay, I will remind you.", "ঠিক আছে, আমি মনে করিয়ে দেব।"); return true
        }
        Regex("""(\d+)\s*(সেকেন্ড|মিনিট|ঘণ্টা|ঘন্টা)(?:এর|র)?\s*(?:একটা\s*)?টাইমার""").find(t)?.let {
            remind(it.groupValues[1].toLong() * bnMs(it.groupValues[2]), "")
            say("Timer set.", "টাইমার সেট করলাম।"); return true
        }
        Regex("""^(.+?)\s*(?:খোলো|খুলো|খুলুন|ওপেন করো|ওপেন কর|চালু করো|চালু কর)$""").find(t)?.let { openApp(it.groupValues[1]); return true }
        Regex("""^(?:খোলো|খুলো|ওপেন)\s+(.+)""").find(t)?.let { openApp(it.groupValues[1]); return true }
        Regex("""^(.+?)\s*(?:বন্ধ করো|বন্ধ কর|বন্ধ করুন|ক্লোজ করো)$""").find(t)?.let { closeApp(it.groupValues[1]); return true }
        Regex("""^(.+?)\s*(?:মেসেজ|এসএমএস|টেক্সট)\s+(?:করো|কর|পাঠাও)\s*(.*)$""").find(t)?.let {
            val who = it.groupValues[1].trim().removeSuffix("কে").trim()
            val num = numberFor(who)
            if (num == null) { say("I could not find a number for $who.", "$who এর নম্বর পাইনি।"); return true }
            say("Opening a message. Tap send.", "মেসেজ খুলছি। সেন্ড চাপুন।")
            go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).putExtra("sms_body", it.groupValues[2])); return true
        }
        Regex("""^(.+?)\s*(?:কল করো|কল কর|ফোন করো|ফোন কর|ডায়াল করো)$""").find(t)?.let {
            val who = it.groupValues[1].trim().removeSuffix("কে").trim()
            val num = numberFor(who)
            if (num == null) { say("I could not find a number for $who.", "$who এর নম্বর পাইনি।"); return true }
            val ok = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
            say("Calling $who", "$who কে কল করছি")
            go(Intent(if (ok) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$num"))); return true
        }
        if ((t.contains("ইমেইল") || t.contains("ইমেল")) && Regex("লেখো|লিখো|তৈরি").containsMatchIn(t)) {
            val subj = t.substringBefore("ইমেইল").substringBefore("ইমেল").replace("সম্পর্কে", "").replace("বিষয়ে", "").trim().ifEmpty { "হ্যালো" }
            say("I drafted an email. Check it and tap send.", "ইমেইল তৈরি করেছি। দেখে সেন্ড চাপুন।")
            go(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
                .putExtra(Intent.EXTRA_SUBJECT, subj).putExtra(Intent.EXTRA_TEXT, "$subj সম্পর্কে লিখছি।\n\nধন্যবাদ")); return true
        }
        if (t.contains("ব্যাটারি") && t.split(" ").size <= 6) {
            val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lv = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            say("Battery is ${lv * 100 / sc} percent", "ব্যাটারি ${lv * 100 / sc} শতাংশ"); return true
        }
        if ((t.contains("সময়") || t.contains("কয়টা বাজে")) && t.split(" ").size <= 4) {
            val ts = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date()); say("It is $ts", "এখন সময় $ts"); return true
        }
        if ((t.contains("তারিখ") || t.contains("আজ কি বার")) && t.split(" ").size <= 4) {
            val ds = SimpleDateFormat("EEEE, MMMM d", Locale.ENGLISH).format(Date()); say(ds, "আজ $ds"); return true
        }
        if (Regex("নিরাপত্তা চেক|হ্যাক চেক|ভাইরাস চেক|সিকিউরিটি চেক").containsMatchIn(t)) {
            say("Opening security settings. Check Play Protect and remove apps you do not recognize.",
                "সিকিউরিটি সেটিংস খুলছি। প্লে প্রোটেক্ট চালু আছে কি না দেখুন এবং অচেনা অ্যাপ মুছে ফেলুন।")
            go(Intent(Settings.ACTION_SECURITY_SETTINGS)); return true
        }
        return false
    }

    private fun commandEn(t: String) {
        if (Regex("""^(stop listening|goodbye|shut down|turn off|exit luca)""").containsMatchIn(t)) {
            say("Goodbye")
            h.postDelayed({ stopSelf() }, 1800)
            return
        }
        if (Regex("""^(go home|home screen|go to home)""").containsMatchIn(t)) {
            go(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)); return
        }
        Regex("""^(?:open|launch|start)\s+(.+)""").find(t)?.let { openApp(it.groupValues[1]); return }
        Regex("""^(?:close|quit|kill)\s+(.+)""").find(t)?.let { closeApp(it.groupValues[1]); return }
        Regex("""^(?:search|google|look up)\s+(.+)""").find(t)?.let {
            say("Searching for ${it.groupValues[1]}", "খুঁজছি"); go(searchIntent(it.groupValues[1])); return
        }
        Regex("""remind me (?:in )?(\d+)\s*(second|sec|minute|min|hour)s?\s*(?:to )?(.*)""").find(t)?.let {
            remind(it.groupValues[1].toLong() * mult(it.groupValues[2]), it.groupValues[3])
            say("Okay, I will remind you in ${it.groupValues[1]} ${it.groupValues[2]}s.", "ঠিক আছে, আমি মনে করিয়ে দেব।"); return
        }
        Regex("""timer (?:for )?(\d+)\s*(second|sec|minute|min|hour)""").find(t)?.let {
            remind(it.groupValues[1].toLong() * mult(it.groupValues[2]), "")
            say("Timer set for ${it.groupValues[1]} ${it.groupValues[2]}s.", "টাইমার সেট করলাম।"); return
        }
        Regex("""^(?:call|dial|phone)\s+(.+)""").find(t)?.let {
            val who = it.groupValues[1]
            val num = numberFor(who)
            if (num == null) { say("I could not find a number for $who.", "$who এর নম্বর পাইনি।"); return }
            val ok = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
            say("Calling $who", "$who কে কল করছি")
            go(Intent(if (ok) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$num")))
            return
        }
        Regex("""^(?:text|message|sms)\s+(.+?)(?:\s+(?:saying|say|that)\s+(.+))?$""").find(t)?.let {
            val who = it.groupValues[1]
            val num = numberFor(who)
            if (num == null) { say("I could not find a number for $who.", "$who এর নম্বর পাইনি।"); return }
            say("Opening a message to $who. Tap send.", "মেসেজ খুলছি। সেন্ড চাপুন।")
            go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).putExtra("sms_body", it.groupValues[2]))
            return
        }
        Regex("""(?:write|draft|compose)\s+(?:an?\s+)?(?:email|mail)(?:\s+to\s+(.+?))?(?:\s+(?:about|regarding|for)\s+(.+))?$""").find(t)?.let {
            val to = it.groupValues[1].replace(" at ", "@").replace(" ", "")
            val subj = if (it.groupValues[2].isBlank()) "Hello" else it.groupValues[2]
            val body = "Hello,\n\nI am writing regarding $subj. Please let me know if you need any more details.\n\nKind regards"
            say("I drafted an email. Check it and tap send.", "ইমেইল তৈরি করেছি। দেখে সেন্ড চাপুন।")
            val addr = if (to.contains("@")) to else ""
            go(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$addr"))
                .putExtra(Intent.EXTRA_SUBJECT, subj).putExtra(Intent.EXTRA_TEXT, body))
            return
        }
        val words = t.split(" ").size
        if (t.contains("battery") && words <= 6) {
            val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lv = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            say("Battery is ${lv * 100 / sc} percent", "ব্যাটারি ${lv * 100 / sc} শতাংশ"); return
        }
        if (Regex("""\btime\b""").containsMatchIn(t) && words <= 5) {
            val ts = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date()); say("It is $ts", "এখন সময় $ts"); return
        }
        if (Regex("""\b(date|today)\b""").containsMatchIn(t) && words <= 5) {
            val ds = SimpleDateFormat("EEEE, MMMM d", Locale.ENGLISH).format(Date()); say(ds, "আজ $ds"); return
        }
        if (Regex("""(safety|hack|security|virus|malware) check""").containsMatchIn(t)) {
            say("Opening security settings. Check Play Protect, review app permissions, and remove apps you do not recognize.",
                "সিকিউরিটি সেটিংস খুলছি। প্লে প্রোটেক্ট ও অ্যাপ পারমিশন দেখুন।")
            go(Intent(Settings.ACTION_SECURITY_SETTINGS)); return
        }
        ask(t)
    }
}
