package com.luca.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(48, 96, 48, 48)
        val info = TextView(this)
        info.textSize = 18f
        fun refresh() {
            val bn = prefs().getString("lang", "en") == "bn"
            info.text = "Luca\n\nLanguage: " + (if (bn) "বাংলা (Bangla)" else "English") +
                "\n\nSay \"Hey Luca, open YouTube\", \"Hey Luca, let's chat\" or \"লুকা, ইউটিউব খোলো\".\n\nDo steps 1 to 3 once."
        }
        refresh()
        col.addView(info)
        fun btn(label: String, action: () -> Unit) {
            val b = Button(this)
            b.text = label
            b.setOnClickListener { action() }
            col.addView(b)
        }
        val keyBox = EditText(this)
        keyBox.hint = "Paste AI key (sk-ant-...) for chat"
        keyBox.setSingleLine(true)
        keyBox.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        col.addView(keyBox)
        btn("Save AI key") {
            prefs().edit().putString("key", keyBox.text.toString().trim()).apply()
            keyBox.setText("")
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }
        btn("1. Start Luca") { start() }
        btn("2. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("3. Keep Luca running (battery)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        btn("Language: English") { prefs().edit().putString("lang", "en").apply(); refresh() }
        btn("ভাষা: বাংলা (Bangla)") { prefs().edit().putString("lang", "bn").apply(); refresh() }
        btn("Stop Luca") { stopService(Intent(this, LucaService::class.java)) }
        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
    }

    private fun prefs() = getSharedPreferences("luca", MODE_PRIVATE)

    private fun start() {
        val need = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 1)
            return
        }
        launch()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launch()
        else Toast.makeText(this, "Luca needs the microphone permission.", Toast.LENGTH_LONG).show()
    }

    private fun launch() {
        val i = Intent(this, LucaService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        Toast.makeText(this, "Luca is listening.", Toast.LENGTH_LONG).show()
    }
}
